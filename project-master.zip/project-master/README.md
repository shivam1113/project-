This is a java console based Hotel Booking Management Application.
